#ifndef STATE_H
#define STATE_H

struct State {
    int x;
    int y;
};

#endif
