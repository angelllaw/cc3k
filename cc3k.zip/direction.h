#ifndef DIRECTION_H
#define DIRECTION_H

enum class Direction {
    N, 
    NE, 
    E, 
    SE, 
    S, 
    SW, 
    W, 
    NW
};

#endif
